//workout model

function getWorkoutModel() {}
